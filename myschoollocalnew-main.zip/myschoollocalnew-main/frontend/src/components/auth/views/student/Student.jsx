import * as React from "react";
import StudentsIcon from "../../../../assests/auth/studentsIcon.svg";
import { ReactComponent as AddIcon } from "../../../../assests/AddIcon.svg";
import { ReactComponent as ImportExcelIcon } from "../../../../assests/ImportExcelIcon.svg";
import { Button, FormControl, FormControlLabel, Radio, RadioGroup, Typography, Select, MenuItem, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions, Alert, CircularProgress, Snackbar } from "@mui/material";
import AuthSearchField from "../../../../customTheme/authSearchField/AuthSearchField";
import { DataGrid } from "@mui/x-data-grid";
import { columns, data, StudentmobileViewColumns } from "./constant";
import { useNavigate } from "react-router-dom";
import { BrowserView, isMobile, MobileView } from "react-device-detect";
import { useDispatch, useSelector } from "react-redux";
import { ListUsers, updateUsers } from "../../../../redux/fetchUsersSlice";
import { RefreshToken } from "../../../../redux/authSlice";
import AddNewStudent from "./addNewStudent/AddNewStudent";
import { mobileViewColumns } from "../school/constants";
import axios from "axios";

export default function StudentRecordTable() {
  const navigate = useNavigate();
  const [searchText, setSearchText] = React.useState();
  const [addNewStudent, setAddNewStudent] = React.useState(false);
  const [schools, setSchools] = React.useState([]);
  const [selectedSchool, setSelectedSchool] = React.useState('');
  const dispatch = useDispatch();
  const { hasMore, usersList, loading } = useSelector(
    (state) => state.usersList
  );
  const { accessToken, refreshToken, tokenExpiry, userRole } = useSelector(
    (state) => state.login
  );
  
  // Bulk Upload State
  const [bulkUploadOpen, setBulkUploadOpen] = React.useState(false);
  const [bulkFile, setBulkFile] = React.useState(null);
  const [bulkUploading, setBulkUploading] = React.useState(false);
  const [bulkResults, setBulkResults] = React.useState(null);
  const [snackbar, setSnackbar] = React.useState({ open: false, message: '', severity: 'success' });
  
  // Fetch schools list for Super Admin filter
  React.useEffect(() => {
    if (userRole === 'SUPER_ADMIN') {
      const fetchSchools = async () => {
        try {
          const response = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/api/rest/schools/list`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
          );
          if (response.data?.data) {
            setSchools(response.data.data);
          }
        } catch (err) {
          // Silent fail
        }
      };
      fetchSchools();
    }
  }, [userRole, accessToken]);
  
  // Download Template
  const handleDownloadTemplate = () => {
    const headers = userRole === 'SUPER_ADMIN' 
      ? ['name*', 'email*', 'mobile_number*', 'school_code*', 'class_name*', 'section*', 'roll_number', 'father_name']
      : ['name*', 'email*', 'mobile_number*', 'class_name*', 'section*', 'roll_number', 'father_name'];
    const sample = userRole === 'SUPER_ADMIN'
      ? ['John Student', 'student@school.com', '9876543210', 'SCH001', 'Class 5', 'A', '101', 'John Father']
      : ['John Student', 'student@school.com', '9876543210', 'Class 5', 'A', '101', 'John Father'];
    const csvContent = headers.join(',') + '\n' + sample.join(',');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students_template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };
  
  const handleFetchData = React.useCallback((schoolCode = '') => {
    let header = {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    };
    let data = {
      role: "STUDENT",
      limit: 100,
    };
    if (schoolCode) {
      data.schoolCode = schoolCode;
    }
    let timestamp = Math.ceil(Date.now() / 1000);
    if (tokenExpiry < timestamp) {
      dispatch(
        RefreshToken({
          headers: header,
          body: {
            refreshToken: refreshToken,
          },
        })
      );
    }
    dispatch(
      ListUsers({
        url: "/rest/users/listUsersByRole",
        headers: header,
        method: "GET",
        body: data,
      })
    );
  }, [accessToken, tokenExpiry, refreshToken, dispatch]);
  
  // Handle Bulk Upload
  const handleBulkUpload = async () => {
    if (!bulkFile) return;
    setBulkUploading(true);
    const formData = new FormData();
    formData.append('file', bulkFile);
    
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}/api/admin/bulk-upload/students`,
        formData,
        { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'multipart/form-data' } }
      );
      setBulkResults(response.data);
      setSnackbar({ open: true, message: `Created ${response.data.success_count || 0} students successfully!`, severity: 'success' });
      handleFetchData();
    } catch (error) {
      setSnackbar({ open: true, message: error.response?.data?.detail || 'Upload failed', severity: 'error' });
    }
    setBulkUploading(false);
  };
  
  const handleAddNewStudent = () => {
    setAddNewStudent(true);
  };
  const handleSearchText = (e) => {
    setSearchText(e.target.value);
  }
  const handleSchoolFilterChange = (e) => {
    setSelectedSchool(e.target.value);
    handleFetchData(e.target.value);
  }
  const handleSearch = async () => {
    // If no search text, fetch all students (with school filter if any)
    if (!searchText || searchText.trim().length < 2) {
      handleFetchData(selectedSchool);
      return;
    }
    
    // Use the search endpoint for robust search across multiple fields (name, code, etc.)
    try {
      let searchUrl = `${process.env.REACT_APP_BACKEND_URL}/api/rest/users/search?query=${encodeURIComponent(searchText)}&role=STUDENT&limit=100`;
      const response = await axios.get(searchUrl, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      
      // Transform results to match expected format
      const users = (response.data?.users || []).map(user => ({
        ...user,
        userId: user.id,
        emailId: user.email
      }));
      
      // Update the redux store
      dispatch(updateUsers(users));
    } catch (err) {
      console.error('Search error:', err);
      // Fallback to regular fetch
      handleFetchData(selectedSchool);
    }
  }
  React.useEffect(() => handleFetchData(), [handleFetchData]);
  if (addNewStudent) {
    return (
      <AddNewStudent
        handleCancel={() => {
          setAddNewStudent(false);
          handleFetchData(selectedSchool); // Refresh list when returning
        }}
        onStudentAdded={() => {
          // Auto-refresh the list after adding a new student
          handleFetchData(selectedSchool);
          setAddNewStudent(false);
        }}
      />
    );
  }
  return (
    <div className="schoolContainer">
      <div className="typoContainer">
        <img alt="" src={StudentsIcon} />
        <Typography
          fontSize="20px"
          fontWeight={400}
          fontFamily={"Proxima Nova"}
        >
          Students
        </Typography>
      </div>
      <div className="schoolBtnContainer">
        <div className="imgBtnContainer">
          {/* School Filter for Super Admin */}
          {userRole === 'SUPER_ADMIN' && schools.length > 0 && (
            <FormControl size="small" style={{ minWidth: 200, marginRight: 10 }}>
              <InputLabel id="school-filter-label">Filter by School</InputLabel>
              <Select
                labelId="school-filter-label"
                value={selectedSchool}
                label="Filter by School"
                onChange={handleSchoolFilterChange}
              >
                <MenuItem value="">All Schools</MenuItem>
                {schools.map((school) => (
                  <MenuItem key={school.code} value={school.code}>
                    {school.name} ({school.code})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          )}
          <AuthSearchField
            id="signUpEmail"
            type="text"
            placeholder="Search by Student Name or ID"
            onChange={handleSearchText}
            inputProps={{ style: { color: '#333', fontWeight: 500 } }}
          />
          <Button variant="outlined" className="authSearchbtn" onClick={handleSearch}>
            Search
          </Button>
        </div>
        <MobileView>
          <div className='schoolRadioButtonCaontainer' style={{ display: 'flex', flexDirection: 'column', flex: '1', gap: '1vw', paddingTop: 10 }}>
            <Typography fontSize="20px" fontWeight={400} fontFamily={"Proxima Nova"} marginTop='3px'>
              Search By
            </Typography>
            <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
              <FormControl >
                <RadioGroup
                  aria-labelledby="filter-radio-group"
                  defaultValue="studentcode"
                  name="radio-buttons-group"
                  style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}
                >
                  <FormControlLabel value="studentcode" control={<Radio />} label="Student Code" />
                  <FormControlLabel value="studentname" control={<Radio />} label="Student Name" />
                </RadioGroup>
              </FormControl>
            </div>
          </div>
        </MobileView>
        <div className="btnCombo">
          <Button
            variant="outline"
            className="blueBtnBg"
            startIcon={<AddIcon />}
            onClick={handleAddNewStudent}
          >
            Add New Student
          </Button>
          <Button
            variant="outline"
            className="blueBtnBg"
            startIcon={<ImportExcelIcon />}
            onClick={() => setBulkUploadOpen(true)}
          >
            Bulk Upload
          </Button>
        </div>
      </div>
      <BrowserView>
        <div className='schoolRadioButtonCaontainer' style={{ display: 'flex', flexDirection: 'row', flex: '1', gap: '1vw' }}>
          <Typography fontSize="20px" fontWeight={400} fontFamily={"Proxima Nova"} marginTop='3px'>
            Search By
          </Typography>
          <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
            <FormControl >
              <RadioGroup
                aria-labelledby="filter-radio-group"
                defaultValue="studentcode"
                name="radio-buttons-group"
                style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}
              >
                <FormControlLabel value="studentcode" control={<Radio />} label="Student Code" />
                <FormControlLabel value="studentname" control={<Radio />} label="Student Name" />
              </RadioGroup>
            </FormControl>
          </div>
        </div>
      </BrowserView>
      <DataGrid
        getRowId={(row) => row.userId}
        columns={isMobile ? StudentmobileViewColumns : columns}
        rows={usersList.map((item) => {return {...item, "handleFetchUserData": handleFetchData}})}
        rowHeight={isMobile ? 170 : 40}
        headerHeight={isMobile ? 70 : 56}
        style={{ backgroundColor: "white", minHeight: "80vh" }}
        scrollbarSize={isMobile ? 1 : 5}
        sx={{
          "& .MuiDataGrid-columnHeadersInner": {
            background: "#B3DAFF",
            fontFamily: "Proxima Nova",
            fontSize: 15,
            fontWeight: 600,
          },
          ".MuiDataGrid-columnSeparator": {
            display: "none",
          },
        }}
        getRowClassName={() => "textFontProxima"}
      // rowsPerPageOptions={[20]}
      />
      
      {/* Bulk Upload Dialog */}
      <Dialog open={bulkUploadOpen} onClose={() => setBulkUploadOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Bulk Upload Students</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            <strong>Required columns (marked with *):</strong> name, email, mobile_number, {userRole === 'SUPER_ADMIN' && 'school_code, '}class_name, section<br/>
            <strong>Optional columns:</strong> roll_number, father_name, address, city, state<br/><br/>
            Auto-generated passwords will be sent to each student&apos;s email.
          </Alert>
          <Button variant="outlined" onClick={handleDownloadTemplate} sx={{ mb: 2 }}>
            Download Template
          </Button>
          <br/>
          <Button variant="outlined" component="label" fullWidth sx={{ py: 2 }}>
            {bulkFile ? bulkFile.name : 'Choose CSV/Excel File'}
            <input type="file" hidden accept=".csv,.xlsx,.xls" onChange={(e) => setBulkFile(e.target.files[0])} />
          </Button>
          {bulkResults && (
            <Alert severity={bulkResults.error_count > 0 ? 'warning' : 'success'} sx={{ mt: 2 }}>
              <strong>Results:</strong><br/>
              ✅ Created: {bulkResults.success_count || 0}<br/>
              ❌ Failed: {bulkResults.error_count || 0}
              {bulkResults.errors && bulkResults.errors.length > 0 && (
                <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                  {bulkResults.errors.slice(0, 5).map((err, i) => <li key={i}>{err}</li>)}
                </ul>
              )}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setBulkUploadOpen(false); setBulkFile(null); setBulkResults(null); }}>Cancel</Button>
          <Button onClick={handleBulkUpload} variant="contained" disabled={bulkUploading || !bulkFile}>
            {bulkUploading ? <CircularProgress size={20} /> : 'Upload'}
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar open={snackbar.open} autoHideDuration={5000} onClose={() => setSnackbar({...snackbar, open: false})}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </div>
  );
}
